import { createLogger ,transports,format} from "winston";
import DailyRotateFile from "winston-daily-rotate-file";

let winston = require('winston');                                                                                                          
// let expressWinston = require('express-winston');                                                                                           
winston.transports.DailyRotateFile = require('winston-daily-rotate-file');
let config = require('config')

// Logger initialized
// module.exports = new (winston.Logger)({
//     transports: [
//       new (winston.transports.Console)(),
//       new (winston.transports.DailyRotateFile)({
//                 filename: config.log.filePath,
//                 level : config.log.level,
//                 datePattern: '.yyyy-MM-dd', //Daily
//                 maxsize : 104857600 //100 MB   
//             }
//           )
//     ]
//   });

const logger = createLogger({
  level:'info',
  format:format.combine(
        format.timestamp(),
        format.json()
      ),
  transports:[
    new transports.Console(),
    new transports.DailyRotateFile({
              filename: config?.log?.filePath+'/directive-tracker_service_info_%DATE%.log',
              level : config?.log?.level,
              datePattern:'YYYY-MM-DD'
    })
  ]
})

export default logger

// import { registerAs } from "@nestjs/config";
// import { transports,format } from "winston";
// import * as DailyRotateFile from 'winston-daily-rotate-file';
// import * as fs from 'fs'
// let config = require('config')

// export default registerAs('logger',()=>({
//   level:config.log.level,
//   format:format.combine(
//     format.timestamp(),
//     format.json()
//   ),
//   transports: [
//     new transports.Console(),
//     new DailyRotateFile({
//               filename: config.log.filePath+'/siteservice_info_%DATE%.log',
//               level : config.log.level,
//               datePattern:'YYYY-MM-DD'
//           }
//         )
//   ]
// }))

