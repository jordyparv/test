import { BadRequestException, ValidationError, ValidationPipe} from "@nestjs/common";
// import { BadRequestExceptionFilter } from './common/exceptions/BadRequestException.filter';
import { NestFactory } from "@nestjs/core";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { AppModule } from "./app.module";
import { HttpRequestExceptionFilter } from "./common/exceptions/BadRequestException.filter";
import { OracleLoggingInterceptor } from "./common/interceptor/OracleLogging.interceptor";
import logger from "config/Log.config";
import * as bodyparser from 'body-parser';

const config = require("config");
let oracledb = require("oracledb");
oracledb.fetchAsString = [oracledb.CLOB, oracledb.NUMBER];

async function bootstrap() {
  try {
    const app = await NestFactory?.create(AppModule);

  
  app?.useLogger(logger)
  app.enableCors();
  const options = new DocumentBuilder()
    .setTitle('DirectiveService')
    .setDescription('directive tracker service')
    .setVersion('0.1')
    .build();

  const document = SwaggerModule?.createDocument(app, options);
  SwaggerModule.setup('api', app, document);
  app?.useGlobalInterceptors(new OracleLoggingInterceptor());
 // Use the global exception filter
 app.useGlobalFilters(new HttpRequestExceptionFilter());

 // Use global pipes to handle validation errors
 app.useGlobalPipes(
   new ValidationPipe({
     whitelist: true,
     forbidNonWhitelisted: true,
     transform: true,
   }))
  
  app.use(bodyparser.json({limit:"100mb"}))
  app.use(bodyparser.urlencoded({limit:"100mb",extended:true}))
  await app?.listen(config?.app?.port);
  console.log('Currently running on port: ' + config?.app?.port);

  } catch (error) {
    console.log('error in bootstrap function ', error);
    
  }
  }

bootstrap();
