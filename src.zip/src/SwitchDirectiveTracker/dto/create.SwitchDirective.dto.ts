import { IsString,IsNotEmpty,IsArray, IsOptional, ArrayNotEmpty, IsInt } from "class-validator";

export class CreateSwitchDirectiveDto{
    @IsString()
    @IsNotEmpty({message:"Group name cannot be empty"})
    group_name:string;
    @IsString()
    @IsNotEmpty({message:"Assigned mgr cannot be empty"})
    assigned_mgr:string;
    @IsString()
    @IsNotEmpty({message:"Created by id cannot be empty"})
    created_by:string
    @IsArray()
    @IsOptional()
    @ArrayNotEmpty({message:"Teams should not be empty if provided"})
    teams:string[];
    @IsArray()
    @IsInt({ each: true })
    @ArrayNotEmpty({message:"Elements cannot be empty"})
    elements:number[];
}