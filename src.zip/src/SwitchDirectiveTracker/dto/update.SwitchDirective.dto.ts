import { IsString, IsOptional, IsArray, IsInt } from 'class-validator';

export class UpdateSwitchDirectiveDto {
  @IsOptional()
  @IsString()
  group_name?: string; // The name of the group to update

  @IsOptional()
  @IsString()
  assigned_mgr?: string; // The manager to be assigned to the group (user ID)

  @IsOptional()
  @IsInt()
  group_id?: number;

  @IsOptional()
  @IsArray()
  teams?: string[]; // A list of teams assigned to the group

  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  elements?: number[]; // List of element IDs to be associated with the group

  @IsString()
  updated_by?: string; // The user who is making the update
}
