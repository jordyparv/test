import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { DirectiveUserGroupMappingEntity } from "./switch.directive.entity.DirectiveUserGroupMappingEntity"; 

@Entity('SEC_CONTACT')
export class SecContactEntity {
  @PrimaryGeneratedColumn()
  CONTACT_ID: number;
  @Column()
  LOGIN_ID: string;
  @Column()
  ENTERPRISE_ID: string;
  @Column()
  EMPLOYEE_ID: number;
  @Column()
  FIRSTNAME: string;
  @Column()
  LASTNAME: string;
  @Column()
  PHONE: string;
  @Column()
  EMAIL: string;
  @Column()
  TITLE: string;
  @Column()
  ROLE: string;
  @Column()
  MANAGER_ID: string;
  @Column()
  DIRECTOR_ID: string;
  @Column()
  MARKET_ID: string;
  @Column()
  MARKET: string;
  @Column()
  SUBMARKET: string
  @Column()
  START_DATE: Date;
  @Column()
  END_DATE: Date;
  @Column()
  CREATED_DATE: Date;
  @Column()
  MODIFIED_DATE: Date;
  @Column()
  NO_LDAP_OVERRIDE: number;
  @Column()
  IS_BETA_USER: number;
  @Column()
  ALT_PHONE: string;
}