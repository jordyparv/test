import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
@Entity('SEC_ROLES')
export class SecRolesEntity {
  @PrimaryGeneratedColumn()
  SEC_ROLES_ID : number;
  @Column()
  ROLE_ID: number;
  @Column()
  ROLE_NAME: string;
  @Column()
  ROLE_DESC: string;
  @Column()
  ROLE_TYPE : string;

}