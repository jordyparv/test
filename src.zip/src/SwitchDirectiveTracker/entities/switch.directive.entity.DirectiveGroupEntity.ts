import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
@Entity('DIRECTIVE_GROUP')
export class DirectiveGroupEntity {
  @PrimaryGeneratedColumn()
  GROUP_ID: number|string;
  @Column()
  GROUP_NAME: string;
  @Column()
  META_CREATED_DATE: Date;
  @Column()
  META_CREATED_BY: string;
  @Column()
  META_LAST_UPDATED_DATE: Date;
  @Column()
  META_LAST_UPDATED_BY: string;
}
