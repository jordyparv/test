import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
@Entity('DIRECTIVE_USER_GROUP_MAPPING') 
export class DirectiveUserGroupMappingEntity {
  @PrimaryGeneratedColumn()
  MAPPING_ID: number|string;
  @Column()
  GROUP_ID: number;
  @Column()
  USER_ID: string;
  @Column()
  META_CREATED_DATE: Date;
  @Column()
  META_CREATED_BY: string;
  @Column()
  META_LAST_UPDATED_DATE: Date;
  @Column()
  META_LAST_UPDATED_BY: string;
  @Column()
  ASSIGNED_TEAM: string;
}



