import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
@Entity('SEC_USERS')
export class SecUsersEntity {
  @PrimaryGeneratedColumn()
  SEC_USERS_ID : number;
  @Column()
  LOGIN_ID: string;
  @Column()
  FIRSTNAME: string;
  @Column()
  LASTNAME: string;
  @Column()
  PHONE: string;
  @Column()
  EMAIL: string;
  @Column()
  STATUS: string;
  @Column()
  TYPE: string;
  @Column()
  SUPERVISOR: string;
  @Column()
  START_DATE: Date;
  @Column()
  END_DATE: Date;
  @Column()
  CREATED_DATE: Date;
  @Column()
  MODIFIED_DATE: Date;
  @Column()
  LOGIN_ID_UPPER : string;
  @Column()
  LAST_LOGGED_IN : Date;
  @Column()
  IS_OFFSHORE : string;
  @Column()
  COUNTRYCODE : string;
  @Column()
  IS_BETA_USER : number;
}