import {
  Entity,
  PrimaryGeneratedColumn,
  Column
} from 'typeorm';
@Entity('DIRECTIVE_ELEMENT_GROUP_MAPPING')
export class DirectiveElementGroupMappingEntity {
  @PrimaryGeneratedColumn()
  ELEMENT_MAPPING_ID: number|string;
  @Column()
  GROUP_ID: number;
  @Column()
  ELEMENT_ID: number;
  @Column()
  META_CREATED_DATE: Date;
  @Column()
  META_CREATED_BY: string;
  @Column()
  META_LAST_UPDATED_DATE: Date;
  @Column()
  META_LAST_UPDATED_BY: string;
 
}
