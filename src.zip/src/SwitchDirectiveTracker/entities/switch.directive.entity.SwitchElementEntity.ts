import { forwardRef } from '@nestjs/common';
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';
import { DirectiveElementGroupMappingEntity } from './switch.directive.entity.DirectiveElementGroupMappingEntity';

@Entity('SWITCH_ELEMENTS')
export class SwitchElementEntity {
  @PrimaryGeneratedColumn()
  ELEMENT_ID: number;
  @Column()
  DESCRIPTION: string;
  @Column()
  ELEMENT_DIVISION: string;
  @Column()
  ELEMENT_DEPT: string;
  @Column()
  ELEMENT_SUB_DEPT: string;
  @Column()
  IS_DISABLED: string;
  @Column()
  META_UNIVERSAL_ID: string;
  @Column()
  META_CREATED_DATE: Date;
  @Column()
  META_CREATED_BY: string;
  @Column()
  META_LAST_UPDATED_DATE: Date;
  @Column()
  META_LAST_UPDATED_BY: string;
  @Column()
  NO_DIRTRACKER: number;
  @Column()
  VENDOR: string;
}