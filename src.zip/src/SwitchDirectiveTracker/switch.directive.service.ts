import {
  HttpException,
  HttpStatus,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Repository } from 'typeorm';
import { DirectiveUserGroupMappingEntity } from './entities/switch.directive.entity.DirectiveUserGroupMappingEntity';
import { DirectiveGroupEntity } from './entities/switch.directive.entity.DirectiveGroupEntity';
import { SwitchElementEntity } from './entities/switch.directive.entity.SwitchElementEntity';
import { DirectiveElementGroupMappingEntity } from './entities/switch.directive.entity.DirectiveElementGroupMappingEntity';
import { SecContactEntity } from './entities/switch.directive.entity.SecContactEntity';
import { SecRolesEntity } from './entities/switch.directive.entity.SecRolesEntity';
import { CreateSwitchDirectiveDto } from './dto/create.SwitchDirective.dto';
import logger from './../../config/Log.config';
import { SecUsersEntity } from './entities/switch.directive.entity.SecUsersEntity';
import { UpdateSwitchDirectiveDto } from './dto/update.SwitchDirective.dto';

@Injectable()
export class SwitchDirectiveService {
  constructor(
    @InjectRepository(DirectiveUserGroupMappingEntity)
    private DirectiveUserGroupMappingEntityRepository: Repository<DirectiveUserGroupMappingEntity>,
    @InjectRepository(DirectiveGroupEntity)
    private DirectiveGroupEntityRepository: Repository<DirectiveGroupEntity>,
    @InjectRepository(DirectiveElementGroupMappingEntity)
    private directiveElementGroupMappingEntityRepository: Repository<DirectiveElementGroupMappingEntity>,
    @InjectRepository(SecContactEntity)
    private SecContactEntityRepository: Repository<SecContactEntity>,
    @InjectRepository(SwitchElementEntity)
    private SwitchElementRepository: Repository<SwitchElementEntity>,
    @InjectRepository(SecUsersEntity)
    private SecUsersEntityRepository: Repository<SecUsersEntity>,
  ) {}

  async findAll(): Promise<DirectiveUserGroupMappingEntity[]> {
    return this.DirectiveUserGroupMappingEntityRepository.find();
  }
  async getSwitchDirectiveMgrTeam(mgrId: string, mapping_id: number) {
    let mgr = await this.DirectiveUserGroupMappingEntityRepository.findBy({
      USER_ID: mgrId,
      MAPPING_ID: mapping_id,
    });

    if (!mgr.length) {
      throw new HttpException(
        { message: 'Manager or mapping id not exist' },
        HttpStatus.BAD_REQUEST,
      );
    }
    const teams = mgr[0].ASSIGNED_TEAM.split(',');

    return this.SecContactEntityRepository.createQueryBuilder('sc')
      .select([
        `TRIM(sc.LASTNAME) || ', '  || TRIM(sc.FIRSTNAME) AS "name"`,
        'sc.ALT_PHONE as "alt_phone"',
        'sc.PHONE as "phone"',
        'sc.ROLE as "role"',
        'sc.EMAIL as "email"',
        'sc.TITLE as "title"',
        'sc.LOGIN_ID as "login_id"',
      ])
      .where('sc.LOGIN_ID in(:...teams)', { teams })
      .getRawMany();
  }

  async findOne(MAPPING_ID: number): Promise<DirectiveUserGroupMappingEntity> {
    return this.DirectiveUserGroupMappingEntityRepository.findOneBy({
      MAPPING_ID: 1,
    });
  }
  // async getSwitchDirective() {
  //   const rawData =
  //     await this.DirectiveGroupEntityRepository.createQueryBuilder('gr')
  //       .select([
  //         `gr.GROUP_NAME AS "group_name"`,
  //         `gr.META_CREATED_BY AS "created_by"`,
  //         `TO_CHAR(TRUNC(gr.META_CREATED_DATE), 'YYYY-MM-DD') AS "created_on"`,
  //         `gr.GROUP_ID AS "group_id"`,
  //         `ugm.MAPPING_ID AS "mapping_id"`,
  //         `ugm.ASSIGNED_TEAM AS "assigned_team"`,
  //         `sc.LASTNAME || ', ' || sc.FIRSTNAME AS "assigned_to"`,
  //         `sele.VENDOR AS "vendor"`,
  //         `sele.ELEMENT_DIVISION AS "elements_division"`,
  //         `sele.ELEMENT_DEPT AS "element_dept"`,
  //         `sele.ELEMENT_ID AS "element_id"`, // Add ELEMENT_ID so we can gather it into the elements array
  //       ])
  //       .innerJoin(
  //         DirectiveUserGroupMappingEntity,
  //         'ugm',
  //         'ugm.GROUP_ID = gr.GROUP_ID',
  //       )
  //       .innerJoin(
  //         DirectiveElementGroupMappingEntity,
  //         'egm',
  //         'egm.GROUP_ID = gr.GROUP_ID',
  //       )
  //       .innerJoin(
  //         SwitchElementEntity,
  //         'sele',
  //         'sele.ELEMENT_ID = egm.ELEMENT_ID',
  //       )
  //       .innerJoin(SecContactEntity, 'sc', 'sc.LOGIN_ID = ugm.USER_ID')
  //       .getRawMany();

  //   // Step 2: Transform the raw data into the desired structure
  //   const groupedData = rawData.reduce(async (acc, row) => {
  //     const teams = await this.SecContactEntityRepository
  //     .createQueryBuilder()
  //     .select([`select TRIM(LASTNAME) || ', ' || TRIM(FIRSTNAME) as "switchtech_name", role as "role",login_id as "login_id"`])
  //     .whereInIds(row?.assigned_team?.split(','))
  //     .getRawMany();
  //     const {
  //       element_id,
  //       elements_division,
  //       element_dept,
  //       group_id,
  //       vendor,
  //       ...rest
  //     } = row;
  //     // Check if the group already exists in the accumulator
  //     let group = acc.find((g) => g.group_id === group_id);
  //     if (!group) {
  //       group = {
  //         elements_division,
  //         vendor,
  //         ...rest,
  //         teams,
  //         elements: [], // Initialize the elements array
  //       };
  //       acc.push(group);
  //     }

  //     // Add the element information to the group's elements array
  //     group.elements.push({
  //       element_id,
  //       element_name:elements_division,
  //       vendor,
  //       sub_element_name:element_dept,
  //     });
  //     group.element_dept = `${group.elements.length} Dept`;
  //     return acc;
  //   }, []);

  //   return groupedData;
  // }
  async getSwitchDirective() {
    // Step 1: Fetch the raw data
    const rawData =
      await this.DirectiveGroupEntityRepository.createQueryBuilder('gr')
        .select([
          `gr.GROUP_NAME AS "group_name"`,
          `gr.META_CREATED_BY AS "created_by"`,
          `TO_CHAR(TRUNC(gr.META_CREATED_DATE), 'YYYY-MM-DD') AS "created_on"`,
          `gr.GROUP_ID AS "group_id"`,
          `ugm.MAPPING_ID AS "mapping_id"`,
          `ugm.ASSIGNED_TEAM AS "assigned_team"`,
          `sc.LASTNAME || ', ' || sc.FIRSTNAME AS "assigned_to"`,
          `ugm.USER_ID AS "manager_id"`,
          `sele.VENDOR AS "vendor"`,
          `sele.ELEMENT_DIVISION AS "elements_division"`,
          `sele.ELEMENT_DEPT AS "element_dept"`,
          `sele.ELEMENT_ID AS "element_id"`,
        ])
        .innerJoin(
          DirectiveUserGroupMappingEntity,
          'ugm',
          'ugm.GROUP_ID = gr.GROUP_ID',
        )
        .innerJoin(
          DirectiveElementGroupMappingEntity,
          'egm',
          'egm.GROUP_ID = gr.GROUP_ID',
        )
        .innerJoin(
          SwitchElementEntity,
          'sele',
          'sele.ELEMENT_ID = egm.ELEMENT_ID',
        )
        .innerJoin(SecContactEntity, 'sc', 'sc.LOGIN_ID = ugm.USER_ID')
        .orderBy('group_name')
        .getRawMany();

    // Step 2: Process the raw data into the desired structure
    const groupedData = [];

    for (const row of rawData) {
      const teams = await this.SecContactEntityRepository.createQueryBuilder(
        'sc',
      )
        .select([
          `TRIM(sc.LASTNAME) || ', ' || TRIM(sc.FIRSTNAME) AS "switchtech_name"`,
          `sc.ROLE AS "role"`,
          `sc.LOGIN_ID AS "login_id"`,
        ])
        .innerJoin(SecUsersEntity, 'su',
          'su.LOGIN_ID = sc.LOGIN_ID AND su.STATUS = :status AND UPPER(sc.ROLE) IN (:...roles)',
          { status: 'A', roles: ['TECHNICIAN', 'SWITCH_TECHNICIAN'] })
        .where(`LOWER(sc.MANAGER_ID) = LOWER(:login_id)`, {
          login_id: row.manager_id,
        })
        .getRawMany();
      let assigned_team_ids = row.assigned_team?.split(',')||[];
      let assigned_team = teams?.map((item) => {
        return {
          switchtech_name: item.switchtech_name,
          login_id: item.login_id,
          role: item.role,
          checked: assigned_team_ids.includes(item.login_id),
        };
      });
      const {
        element_id,
        elements_division,
        element_dept,
        group_id,
        vendor,
        ...rest
      } = row;

      // Find the existing group or create a new one if it doesn't exist
      let group = groupedData.find((g) => g.group_id === group_id);
      if (!group) {
        group = {
          group_id,
          elements_division,
          vendor,
          ...rest,
          assigned_team,
          elements: [], // Initialize the elements array
        };
        console.log({ teams });
        groupedData.push(group);
      }

      // Add the element information to the group's elements array
      group.elements.push({
        element_id,
        element_name: elements_division,
        vendor,
        sub_element_name: element_dept,
      });

      // Update element_dept count
      group.element_dept = `${group.elements.length} Dept`;
    }

    // Step 3: Return the grouped data
    return groupedData;
  }

  async create(createSwitchDirectiveDto: CreateSwitchDirectiveDto) {
    const queryRunner =
      this.DirectiveGroupEntityRepository.manager.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      const existingGroup = await queryRunner.manager
        .createQueryBuilder()
        .select('g.GROUP_ID')
        .from(DirectiveGroupEntity, 'g')
        .where('g.GROUP_NAME = :groupName', {
          groupName: createSwitchDirectiveDto.group_name,
        })
        .getOne();

      if (existingGroup) {
        throw new HttpException(
          {
            message: 'Group name already exists',
            status: HttpStatus.BAD_REQUEST,
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const groupIdQuery = await queryRunner.manager.query(
        'SELECT DIRECTIVE_GROUP_SEQ.NEXTVAL FROM dual',
      );
      const groupId = groupIdQuery[0]?.NEXTVAL;

      await queryRunner.manager
        .createQueryBuilder()
        .insert()
        .into(DirectiveGroupEntity)
        .values({
          GROUP_NAME: createSwitchDirectiveDto.group_name,
          GROUP_ID: groupId,
          META_CREATED_BY: createSwitchDirectiveDto.created_by,
          META_LAST_UPDATED_BY: createSwitchDirectiveDto.created_by,
          META_CREATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
          META_LAST_UPDATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
        })
        .execute();

      const mappingIdQuery = await queryRunner.manager.query(
        'SELECT DIRECTIVE_USER_GROUP_MAPPING_SEQ.NEXTVAL FROM dual',
      );
      const mappingId = mappingIdQuery[0]?.NEXTVAL;

      await queryRunner.manager
        .createQueryBuilder()
        .insert()
        .into(DirectiveUserGroupMappingEntity)
        .values({
          MAPPING_ID: mappingId,
          USER_ID: createSwitchDirectiveDto.assigned_mgr,
          GROUP_ID: groupId,
          META_CREATED_BY: createSwitchDirectiveDto.created_by,
          META_LAST_UPDATED_BY: createSwitchDirectiveDto.created_by,
          META_CREATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
          META_LAST_UPDATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
          ASSIGNED_TEAM: createSwitchDirectiveDto.teams
            ? createSwitchDirectiveDto.teams.join(',')
            : '',
        })
        .execute();

      if (createSwitchDirectiveDto.elements?.length) {
        const elementsToInsert = await Promise.all(
          createSwitchDirectiveDto.elements.map(async (ELEMENT_ID) => {
            const elementMappingIdQuery = await queryRunner.manager.query(
              'SELECT DIRECTIVE_ELEMENT_GROUP_MAPPING_SEQ.NEXTVAL FROM dual',
            );
            const elementMappingId = elementMappingIdQuery[0]?.NEXTVAL;

            return {
              ELEMENT_MAPPING_ID: elementMappingId,
              GROUP_ID: groupId,
              ELEMENT_ID,
              META_CREATED_BY: createSwitchDirectiveDto.created_by,
              META_LAST_UPDATED_BY: createSwitchDirectiveDto.created_by,
              META_CREATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
              META_LAST_UPDATED_DATE: () =>
                'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
            };
          }),
        );

        await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(DirectiveElementGroupMappingEntity)
          .values(elementsToInsert)
          .execute();
      }

      await queryRunner.commitTransaction();

      return {
        message: 'Switch directive saved successfully',
        status: HttpStatus.CREATED,
      };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      logger.error(`Unable to add switch directive => ${error.message}`);

      throw new HttpException(
        { message: error.message },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async update(
    groupId: number,
    updateSwitchDirectiveDto: UpdateSwitchDirectiveDto,
  ) {
    const queryRunner =
      this.DirectiveGroupEntityRepository.manager.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      // Check if the group exists
      const existingGroup = await queryRunner.manager
        .createQueryBuilder()
        .select('g.GROUP_ID')
        .from(DirectiveGroupEntity, 'g')
        .where('g.GROUP_ID = :groupId', { groupId })
        .getOne();

      if (!existingGroup) {
        throw new HttpException(
          {
            message: 'Group not found',
            status: HttpStatus.NOT_FOUND,
          },
          HttpStatus.NOT_FOUND,
        );
      }

      // Update the DirectiveGroupEntity
      await queryRunner.manager
        .createQueryBuilder()
        .update(DirectiveGroupEntity)
        .set({
          GROUP_NAME:
            updateSwitchDirectiveDto.group_name || existingGroup.GROUP_NAME,
          META_LAST_UPDATED_BY: updateSwitchDirectiveDto.updated_by,
          META_LAST_UPDATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
        })
        .where('GROUP_ID = :groupId', { groupId })
        .execute();

      // Update the DirectiveUserGroupMappingEntity
      if (updateSwitchDirectiveDto.assigned_mgr) {
        await queryRunner.manager
          .createQueryBuilder()
          .update(DirectiveUserGroupMappingEntity)
          .set({
            USER_ID: updateSwitchDirectiveDto.assigned_mgr,
            META_LAST_UPDATED_BY: updateSwitchDirectiveDto.updated_by,
            META_LAST_UPDATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
            ASSIGNED_TEAM: updateSwitchDirectiveDto.teams
              ? updateSwitchDirectiveDto.teams.join(',')
              : '',
          })
          .where('GROUP_ID = :groupId', { groupId })
          .execute();
      }

      if (updateSwitchDirectiveDto.teams) {
        await queryRunner.manager
          .createQueryBuilder()
          .update(DirectiveUserGroupMappingEntity)
          .set({
            META_LAST_UPDATED_BY: updateSwitchDirectiveDto.updated_by,
            META_LAST_UPDATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
            ASSIGNED_TEAM: updateSwitchDirectiveDto.teams
              ? updateSwitchDirectiveDto.teams.join(',')
              : '',
          })
          .where('GROUP_ID = :groupId', { groupId })
          .execute();
      }

      // Handle updating elements (either update or remove old elements)
      if (updateSwitchDirectiveDto.elements?.length) {
        // Delete existing elements for the group
        await queryRunner.manager
          .createQueryBuilder()
          .delete()
          .from(DirectiveElementGroupMappingEntity)
          .where('GROUP_ID = :groupId', { groupId })
          .execute();

        // Insert updated elements
        const elementsToInsert = await Promise.all(
          updateSwitchDirectiveDto.elements.map(async (ELEMENT_ID) => {
            const elementMappingIdQuery = await queryRunner.manager.query(
              'SELECT DIRECTIVE_ELEMENT_GROUP_MAPPING_SEQ.NEXTVAL FROM dual',
            );
            const elementMappingId = elementMappingIdQuery[0]?.NEXTVAL;

            return {
              ELEMENT_MAPPING_ID: elementMappingId,
              GROUP_ID: groupId,
              ELEMENT_ID,
              META_CREATED_BY: updateSwitchDirectiveDto.updated_by,
              META_LAST_UPDATED_BY: updateSwitchDirectiveDto.updated_by,
              META_CREATED_DATE: () => 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
              META_LAST_UPDATED_DATE: () =>
                'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)',
            };
          }),
        );

        await queryRunner.manager
          .createQueryBuilder()
          .insert()
          .into(DirectiveElementGroupMappingEntity)
          .values(elementsToInsert)
          .execute();
      }

      await queryRunner.commitTransaction();

      return {
        message: 'Switch directive updated successfully',
        status: HttpStatus.OK,
      };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      logger.error(`Unable to update switch directive => ${error.message}`);

      throw new HttpException(
        { message: error.message },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    } finally {
      await queryRunner.release();
    }
  }

  async delete(id: number): Promise<void> {
    // await this.DirectiveUserGroupMappingEntityRepository.delete(id);
  }
  async typeaheadManagers(searchValue: string): Promise<any> {
    const query = this.SecContactEntityRepository.createQueryBuilder('sc')
      .select([
        `TRIM(sc.LASTNAME) || ', ' || TRIM(sc.FIRSTNAME) || ' - ' || sc.LOGIN_ID || ' - ' || sc.ROLE AS "display_name"`,
        'sc.LOGIN_ID as "login_id"',
      ])
      .innerJoin(
        SecUsersEntity,
        'su',
        'su.LOGIN_ID = sc.LOGIN_ID AND su.STATUS = :status',
        { status: 'A' },
      )
      .where('UPPER(sc.ROLE) IN (:...roles)', {
        roles: ['CELL_SWITCH_MANAGER', 'SWITCH_MANAGER'],
      })
      .andWhere(
        new Brackets((qb) => {
          qb.where('LOWER(sc.FIRSTNAME) LIKE :firstname', {
            firstname: `%${searchValue.toLowerCase()}%`,
          }).orWhere('LOWER(sc.LASTNAME) LIKE :lastname', {
            lastname: `%${searchValue.toLowerCase()}%`,
          });
        }),
      );

    const results = await query.getRawMany();
    return results;
  }

  async getDistinctElementDivision(): Promise<any> {
    try {
      const result = await this.SwitchElementRepository.createQueryBuilder(
        'switch_Elements',
      )
        .select('DISTINCT switch_Elements.ELEMENT_DIVISION')
        .getRawMany();
      return {
        elementdivision: result.map((row) => row.ELEMENT_DIVISION),
      };
    } catch (error) {
      throw new InternalServerErrorException(
        'Error while fetching distinct element divisions',
        error.message,
      );
    }
  }

  async getDistinctElementVendor(): Promise<any> {
    try {
      const result = await this.SwitchElementRepository.createQueryBuilder(
        'switch_Elements',
      )
        .select('DISTINCT switch_Elements.VENDOR')
        .where('switch_Elements.VENDOR IS NOT NULL')
        .getRawMany();
      return {
        elementvendors: result.map((row) => row.VENDOR),
      };
    } catch (error) {
      throw new InternalServerErrorException(
        'Error while fetching distinct element vendors',
        error.message,
      );
    }
  }

  async getTechnicians(
    loginId: string,
    isConditionTrue: boolean,
  ): Promise<any> {
    const commonQuery = `
      select TRIM(sc.LASTNAME) || ', ' || TRIM(sc.FIRSTNAME) as switchtech_name, sc.role,sc.login_id
      from sec_contact sc
      join sec_users su on su.LOGIN_ID = sc.LOGIN_ID and su.STATUS = 'A'
      inner join sec_roles sr on sr.role_name = sc.role
      where sc.MANAGER_ID = :login_id
    `;

    // If the condition is true, include the ROLE_ID 500(for switch_technician) OR 300(for technician(field_technician))  in the WHERE clause
    const query = isConditionTrue
      ? commonQuery + ` and (sr.ROLE_ID = 500 or sr.ROLE_ID = 300)`
      : commonQuery + ` and sr.ROLE_ID = 500`;

    try {
      const result = await this.SecContactEntityRepository.query(query, [
        loginId,
      ]);

      const transformedResult = result.map((item) => {
        const transformedItem = {};
        for (const key in item) {
          if (item.hasOwnProperty(key)) {
            transformedItem[key.toLowerCase()] = item[key];
          }
        }
        return transformedItem;
      });

      return transformedResult;
    } catch (error) {
      console.error('Error executing query:', error);
      throw new Error('Failed to fetch technician details');
    }
  }

  async getElementDetails(
    elementDivision: string,
    vendor: string,
  ): Promise<any> {
    const query = `
      SELECT ELEMENT_DEPT || ' ' || ELEMENT_SUB_DEPT AS ELEMENT_DETAILS, ELEMENT_ID
      FROM switch_elements
      WHERE LOWER(ELEMENT_DIVISION) = LOWER(:element_division)
      AND LOWER(VENDOR) = LOWER(:vendor)
    `;

    try {
      const result = await this.SwitchElementRepository.query(query, [
        elementDivision,
        vendor,
      ]);

      const transformedResult = result.map((item) => {
        const transformedItem = {};
        for (const key in item) {
          if (item.hasOwnProperty(key)) {
            transformedItem[key.toLowerCase()] = item[key];
          }
        }
        return transformedItem;
      });

      return transformedResult;
    } catch (error) {
      console.error('Error executing query:', error);
      throw new Error('Failed to fetch element details');
    }
  }
}
