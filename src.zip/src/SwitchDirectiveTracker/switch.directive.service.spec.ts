import { Test, TestingModule } from '@nestjs/testing';
import { SwitchDirectiveService } from './switch.directive.service';
import { HttpException, HttpStatus, InternalServerErrorException } from '@nestjs/common';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DirectiveUserGroupMappingEntity } from './entities/switch.directive.entity.DirectiveUserGroupMappingEntity';
import { DirectiveGroupEntity } from './entities/switch.directive.entity.DirectiveGroupEntity';
import { DirectiveElementGroupMappingEntity } from './entities/switch.directive.entity.DirectiveElementGroupMappingEntity';
import { SecContactEntity } from './entities/switch.directive.entity.SecContactEntity';
import { SwitchElementEntity } from './entities/switch.directive.entity.SwitchElementEntity';
import { SecUsersEntity } from './entities/switch.directive.entity.SecUsersEntity';
import { CreateSwitchDirectiveDto } from './dto/create.SwitchDirective.dto';

describe('SwitchDirectiveService', () => {
  let service: SwitchDirectiveService;
  let directiveUserGroupMappingRepo: Repository<DirectiveUserGroupMappingEntity>;
  let directiveGroupRepo: Repository<DirectiveGroupEntity>;
  let directiveElementGroupMappingRepo: Repository<DirectiveElementGroupMappingEntity>;
  let secContactRepo: Repository<SecContactEntity>;
  let switchElementRepo: Repository<SwitchElementEntity>;
  let secUsersRepo: Repository<SecUsersEntity>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SwitchDirectiveService,
        {
          provide: getRepositoryToken(DirectiveUserGroupMappingEntity),
          useClass: Repository,
        },
        {
          provide: getRepositoryToken(DirectiveGroupEntity),
          useClass: Repository,
        },
        {
          provide: getRepositoryToken(DirectiveElementGroupMappingEntity),
          useClass: Repository,
        },
        {
          provide: getRepositoryToken(SecContactEntity),
          useClass: Repository,
        },
        {
          provide: getRepositoryToken(SwitchElementEntity),
          useClass: Repository,
        },
        {
          provide: getRepositoryToken(SecUsersEntity),
          useClass: Repository,
        },
      ],
    }).compile();

    service = module.get<SwitchDirectiveService>(SwitchDirectiveService);
    directiveUserGroupMappingRepo = module.get<Repository<DirectiveUserGroupMappingEntity>>(
      getRepositoryToken(DirectiveUserGroupMappingEntity),
    );
    directiveGroupRepo = module.get<Repository<DirectiveGroupEntity>>(
      getRepositoryToken(DirectiveGroupEntity),
    );
    directiveElementGroupMappingRepo = module.get<Repository<DirectiveElementGroupMappingEntity>>(
      getRepositoryToken(DirectiveElementGroupMappingEntity),
    );
    secContactRepo = module.get<Repository<SecContactEntity>>(getRepositoryToken(SecContactEntity));
    switchElementRepo = module.get<Repository<SwitchElementEntity>>(
      getRepositoryToken(SwitchElementEntity),
    );
    secUsersRepo = module.get<Repository<SecUsersEntity>>(getRepositoryToken(SecUsersEntity));
  });

   describe('findAll', () => {
    it('should return all DirectiveUserGroupMapping entities', async () => {
      const mockData = [{ id: 1 }, { id: 2 }];
      jest.spyOn(directiveUserGroupMappingRepo, 'find').mockResolvedValue(mockData as any);

      const result = await service.findAll();
      expect(result).toEqual(mockData);
      expect(directiveUserGroupMappingRepo.find).toHaveBeenCalledTimes(1);
    });
  });

  describe('findOne', () => {
    it('should return a DirectiveUserGroupMapping entity by MAPPING_ID', async () => {
      const mockEntity = { id: 1 };
      jest.spyOn(directiveUserGroupMappingRepo, 'findOneBy').mockResolvedValue(mockEntity as any);

      const result = await service.findOne(1);
      expect(result).toEqual(mockEntity);
      expect(directiveUserGroupMappingRepo.findOneBy).toHaveBeenCalledWith({ MAPPING_ID: 1 });
    });
});

  describe('getSwitchDirective', () => {
  it('should return grouped and transformed data', async () => {
    const rawData = [
      {
        group_name: 'Group 1',
        created_by: 'User A',
        created_on: '2024-12-30',
        group_id: '1',
        vendor: 'Vendor 1',
        mapping_id: 'M1',
        assigned_to: 'LastName, FirstName',
        element_id: 'E1',
        elements_division: 'Division 1',
        element_dept: 'Dept 1',
      },
      {
        group_name: 'Group 1',
        created_by: 'User A',
        created_on: '2024-12-30',
        group_id: '1',
        vendor: 'Vendor 1',
        mapping_id: 'M1',
        assigned_to: 'LastName, FirstName',
        element_id: 'E2',
        elements_division: 'Division 2',
        element_dept: 'Dept 2',
      },
    ];

    jest.spyOn(directiveGroupRepo, 'createQueryBuilder').mockImplementation(() => {
      return {
        select: jest.fn().mockReturnThis(),
        innerJoin: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockResolvedValue(rawData),
      } as any;
    });

    const result = await service.getSwitchDirective();

    expect(result).toEqual([
      {
        group_name: 'Group 1',
        group_id: '1',
        mapping_id: 'M1',
        assigned_to: 'LastName, FirstName',
        vendor: 'Vendor 1',
        elements_division: 'Division 1',
        created_by: 'User A',
        created_on: '2024-12-30',
        elements: [
          {
            element_id: 'E1',
            element_name: 'Division 1',
            sub_element_name: 'Dept 1',
          },
          {
            element_id: 'E2',
            element_name: 'Division 2',
            sub_element_name: 'Dept 2',
          },
        ],
        element_dept: '2 Dept',
      },
    ]);
  });
});

  describe('getSwitchDirectiveMgrTeam', () => {
    it('should throw HttpException if no manager or mapping is found', async () => {
      jest.spyOn(directiveUserGroupMappingRepo, 'findBy').mockResolvedValue([]);

      await expect(service.getSwitchDirectiveMgrTeam('mgr1', 1)).rejects.toThrow(
        new HttpException(
          { message: 'Manager or mapping id not exist' },
          HttpStatus.BAD_REQUEST,
        ),
      );

      expect(directiveUserGroupMappingRepo.findBy).toHaveBeenCalledWith({ MAPPING_ID: 1, USER_ID: 'mgr1' });
    });

    it('should return team data if manager is found', async () => {
      jest.spyOn(directiveUserGroupMappingRepo, 'findBy').mockResolvedValue([
        { ASSIGNED_TEAM: 'team1,team2' },
      ] as any);

      jest.spyOn(secContactRepo, 'createQueryBuilder').mockReturnValue({
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockResolvedValue([{ name: 'John Doe' }]),
      } as any);

      const result = await service.getSwitchDirectiveMgrTeam('mgr1', 1);
      expect(result).toEqual([{ name: 'John Doe' }]);
      expect(directiveUserGroupMappingRepo.findBy).toHaveBeenCalledWith({ MAPPING_ID: 1, USER_ID: 'mgr1' });
      expect(secContactRepo.createQueryBuilder).toHaveBeenCalled();
    });
  });

  describe('typeaheadManagers', () => {
    it('should return search results when query matches', async () => {
      const mockResults = [
        { display_name: 'Smith, John - JSmith - CELL_SWITCH_MANAGER', login_id: 'JSmith' },
      ];

      jest.spyOn(secContactRepo, 'createQueryBuilder').mockReturnValue({
        select: jest.fn().mockReturnThis(),
        innerJoin: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockResolvedValue(mockResults),
      } as any);

      const result = await service.typeaheadManagers('john');
      expect(result).toEqual(mockResults);
      expect(secContactRepo.createQueryBuilder).toHaveBeenCalledTimes(1);
    });

    it('should return an empty array when no matches are found', async () => {
      jest.spyOn(secContactRepo, 'createQueryBuilder').mockReturnValue({
        select: jest.fn().mockReturnThis(),
        innerJoin: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockResolvedValue([]),
      } as any);

      const result = await service.typeaheadManagers('unknown');
      expect(result).toEqual([]);
      expect(secContactRepo.createQueryBuilder).toHaveBeenCalledTimes(1);
    });
  });

  describe('getDistinctElementDivision', () => {
    it('should return distinct element divisions', async () => {
      const mockData = [{ ELEMENT_DIVISION: 'division1' }, { ELEMENT_DIVISION: 'division2' }];
      jest.spyOn(switchElementRepo, 'createQueryBuilder').mockReturnValue({
        select: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockResolvedValue(mockData),
      } as any);

      const result = await service.getDistinctElementDivision();
      expect(result).toEqual({ elementdivision: ['division1', 'division2'] });
      expect(switchElementRepo.createQueryBuilder).toHaveBeenCalled();
    });

    it('should throw HttpException on query failure', async () => {
      jest.spyOn(switchElementRepo, 'createQueryBuilder').mockImplementation(() => {
        throw new Error('Query failed');
      });

      await expect(service.getDistinctElementDivision()).rejects.toThrow(
        new HttpException('Error while fetching distinct element divisions', HttpStatus.INTERNAL_SERVER_ERROR),
      );
    });
  });

  describe('getDistinctElementVendor', () => {
    it('should return distinct element vendors', async () => {
      const mockVendors = [{ VENDOR: 'Vendor1' }, { VENDOR: 'Vendor2' }];
      jest.spyOn(switchElementRepo, 'createQueryBuilder').mockReturnValue({
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockResolvedValue(mockVendors),
      } as any);

      const result = await service.getDistinctElementVendor();
      expect(result).toEqual({
        elementvendors: ['Vendor1', 'Vendor2'],
      });
      expect(switchElementRepo.createQueryBuilder).toHaveBeenCalledWith('switch_Elements');
    });

    it('should throw InternalServerErrorException on query failure', async () => {
      jest.spyOn(switchElementRepo, 'createQueryBuilder').mockReturnValue({
        select: jest.fn().mockReturnThis(),
        where: jest.fn().mockReturnThis(),
        getRawMany: jest.fn().mockRejectedValue(new Error('Query failed')),
      } as any);

      await expect(service.getDistinctElementVendor()).rejects.toThrow(
        new InternalServerErrorException('Error while fetching distinct element vendors', 'Query failed'),
      );
    });
  });

  describe('getTechnicians', () => {
    it('should return technicians when condition is true', async () => {
      const mockResults = [
        { SWITCHTECH_NAME: 'Doe, John', ROLE: 'Technician', LOGIN_ID: 'tech1' },
      ];
      jest.spyOn(secContactRepo, 'query').mockResolvedValue(mockResults);

      const result = await service.getTechnicians('manager1', true);
      expect(result).toEqual([
        { switchtech_name: 'Doe, John', role: 'Technician', login_id: 'tech1' },
      ]);
      expect(secContactRepo.query).toHaveBeenCalledWith(expect.any(String), ['manager1']);
    });

    it('should return technicians when condition is false', async () => {
      const mockResults = [
        { SWITCHTECH_NAME: 'Smith, Alice', ROLE: 'Field Technician', LOGIN_ID: 'tech2' },
      ];
      jest.spyOn(secContactRepo, 'query').mockResolvedValue(mockResults);

      const result = await service.getTechnicians('manager1', false);
      expect(result).toEqual([
        { switchtech_name: 'Smith, Alice', role: 'Field Technician', login_id: 'tech2' },
      ]);
      expect(secContactRepo.query).toHaveBeenCalledWith(expect.any(String), ['manager1']);
    });

    it('should throw an error on query failure', async () => {
      jest.spyOn(secContactRepo, 'query').mockRejectedValue(new Error('Query failed'));

      await expect(service.getTechnicians('manager1', true)).rejects.toThrow(
        new Error('Failed to fetch technician details'),
      );
    });
  });

  describe('getElementDetails', () => {
    it('should return element details based on division and vendor', async () => {
      const mockResults = [
        { ELEMENT_DETAILS: 'Dept1 SubDept1', ELEMENT_ID: '1' },
        { ELEMENT_DETAILS: 'Dept2 SubDept2', ELEMENT_ID: '2' },
      ];
      jest.spyOn(switchElementRepo, 'query').mockResolvedValue(mockResults);

      const result = await service.getElementDetails('Division1', 'Vendor1');
      expect(result).toEqual([
        { element_details: 'Dept1 SubDept1', element_id: '1' },
        { element_details: 'Dept2 SubDept2', element_id: '2' },
      ]);
      expect(switchElementRepo.query).toHaveBeenCalledWith(expect.any(String), ['Division1', 'Vendor1']);
    });

    it('should throw an error on query failure', async () => {
      jest.spyOn(switchElementRepo, 'query').mockRejectedValue(new Error('Query failed'));

      await expect(service.getElementDetails('Division1', 'Vendor1')).rejects.toThrow(
        new Error('Failed to fetch element details'),
      );
    });
});
});
