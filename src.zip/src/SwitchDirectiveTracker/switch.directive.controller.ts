import {
  Controller,
  Get,
  Param,
  Post,
  Body,
  Put,
  Delete,
  Query,
  InternalServerErrorException,
} from '@nestjs/common';

import { SwitchDirectiveService } from './switch.directive.service';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { DirectiveUserGroupMappingEntity } from './entities/switch.directive.entity.DirectiveUserGroupMappingEntity';
import { CreateSwitchDirectiveDto } from './dto/create.SwitchDirective.dto';
import { UpdateSwitchDirectiveDto } from './dto/update.SwitchDirective.dto';
@Controller('directive')
export class SwitchDirectiveController {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly directiveService: SwitchDirectiveService,
  ) {}

  @Get('/switch-directive')
  async findAll(): Promise<DirectiveUserGroupMappingEntity[]> {
    return this.directiveService.getSwitchDirective();
  }

  @Get('/switch-directive-team/:mgrId/:mapping_id')
  async getSwitchDirectiveMgrTeam(@Param('mgrId') mgrId: string , @Param('mapping_id') mapping_id:number) {
        return this.directiveService.getSwitchDirectiveMgrTeam(mgrId,mapping_id);
  }
  @Get(':id')
  async findOne(
    @Param('id') id: number,
  ): Promise<DirectiveUserGroupMappingEntity> {
    return this.directiveService.findOne(id);
  }
  @Post('/switch-directive')
  async create(
    @Body() createSwitchDirectiveDto: CreateSwitchDirectiveDto,
  ) {
    return this.directiveService.create(createSwitchDirectiveDto);
  }

  @Put('/switch-directive/:group_id')
  async update(@Param('group_id') group_id: number, @Body() data: UpdateSwitchDirectiveDto) {
    return this.directiveService.update(group_id, data);
  }
  @Delete(':id')
  async remove(@Param('id') id: number): Promise<void> {
    return this.directiveService.delete(id);
  }

  @Get('/search/managers')
  async typeaheadManagers(@Query('searchValue') searchValue: string) {
    if (!searchValue) {
      return { message: 'Please provide a search value' };
    }
    const managers = await this.directiveService.typeaheadManagers(searchValue);
    return managers;
  }

  @Get('/manager/technicians')
  async getTechnicians(
    @Query('login_id') loginId: string,  // The login_id is passed from the frontend
    @Query('condition') condition: string, // The condition to execute true/false query
  ): Promise<any> {
    const isConditionTrue = condition.toLowerCase() === 'true'; // Convert the condition to boolean
    return this.directiveService.getTechnicians(loginId, isConditionTrue);
  }


  @Get('/element/division')
  async getElementDivision() {
    try {
      return await this.directiveService.getDistinctElementDivision();
    } catch (error) {
      throw new InternalServerErrorException('Failed to retrieve element divisions', error.message);
    }
  }
  @Get('/element/vendor')
  async getElementVendor() {
    try {
      return await this.directiveService.getDistinctElementVendor();
    } catch (error) {
      throw new InternalServerErrorException('Failed to retrieve element divisions', error.message);
    }
  }

  @Get('/elementDept/elementSubDept')
  async getElementDetails(
    @Query('element_division') elementDivision: string,
    @Query('vendor') vendor: string
  ) {
    if (!elementDivision || !vendor) {
      throw new Error('Both element_division and vendor are required');
    }

    return await this.directiveService.getElementDetails(elementDivision, vendor);
  }
}
