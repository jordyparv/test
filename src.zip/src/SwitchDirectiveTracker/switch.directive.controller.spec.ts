import { Test, TestingModule } from '@nestjs/testing';
import { SwitchDirectiveController } from './switch.directive.controller';
import { SwitchDirectiveService } from './switch.directive.service';
import { DataSource } from 'typeorm';
import { InternalServerErrorException } from '@nestjs/common';
import { CreateSwitchDirectiveDto } from './dto/create.SwitchDirective.dto';
import { UpdateSwitchDirectiveDto } from './dto/update.SwitchDirective.dto';

describe('SwitchDirectiveController', () => {
  let controller: SwitchDirectiveController;
  let directiveService: SwitchDirectiveService;
  let dataSource: DataSource;

  // Mocking the SwitchDirectiveService
  const mockDirectiveService = {
    getSwitchDirective: jest.fn(),
    getSwitchDirectiveMgrTeam: jest.fn(),
    findOne: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    typeaheadManagers: jest.fn(),
    getTechnicians: jest.fn(),
    getDistinctElementDivision: jest.fn(),
    getDistinctElementVendor: jest.fn(),
    getElementDetails: jest.fn(),
  };

  // Mocking the DataSource
  const mockDataSource = {
    initialize: jest.fn().mockResolvedValue(undefined),
    destroy: jest.fn().mockResolvedValue(undefined),
    getRepository: jest.fn().mockReturnValue({
      find: jest.fn(),
      findOne: jest.fn(),
      save: jest.fn(),
      delete: jest.fn(),
    }),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SwitchDirectiveController],
      providers: [
        { provide: SwitchDirectiveService, useValue: mockDirectiveService },
        { provide: DataSource, useValue: mockDataSource },
      ],
    }).compile();

    controller = module.get<SwitchDirectiveController>(SwitchDirectiveController);
    directiveService = module.get<SwitchDirectiveService>(SwitchDirectiveService);
    dataSource = module.get<DataSource>(DataSource);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
    expect(dataSource).toBeDefined();
  });

  describe('GET /directive/switch-directive', () => {
    it('should return all switch directives', async () => {
      const result = [{ id: 1, name: 'Test Directive' }];
      mockDirectiveService.getSwitchDirective.mockResolvedValue(result);

      expect(await controller.findAll()).toEqual(result);
    });
  });

  describe('getSwitchDirectiveMgrTeam', () => {
    it('should call getSwitchDirectiveMgrTeam with correct parameters', async () => {
      const mgrId = '123';
      const mapping_id = 1;
      const result = { team: 'Team Data' };
      mockDirectiveService.getSwitchDirectiveMgrTeam.mockResolvedValue(result);

      const response = await controller.getSwitchDirectiveMgrTeam(mgrId, mapping_id);

      expect(mockDirectiveService.getSwitchDirectiveMgrTeam).toHaveBeenCalledWith(mgrId, mapping_id);
      expect(response).toEqual(result);
    });
  });

  describe('findOne', () => {
    it('should call findOne with correct parameters', async () => {
      const id = 1;
      const result = { id: 1, name: 'Directive' };
      mockDirectiveService.findOne.mockResolvedValue(result);

      const response = await controller.findOne(id);

      expect(mockDirectiveService.findOne).toHaveBeenCalledWith(id);
      expect(response).toEqual(result);
    });
  });
  describe('create', () => {
    it('should call create with correct parameters', async () => {
      const dto = new CreateSwitchDirectiveDto();
      const result = { success: true };
      mockDirectiveService.create.mockResolvedValue(result); // Mock service method

      const response = await controller.create(dto);

      expect(mockDirectiveService.create).toHaveBeenCalledWith(dto);
      expect(response).toEqual(result);
    });
  });

  describe('update', () => {
    it('should call update with correct parameters', async () => {
      const group_id = 1;
      const dto = new UpdateSwitchDirectiveDto();
      const result = { success: true };
      mockDirectiveService.update.mockResolvedValue(result); // Mock service method

      const response = await controller.update(group_id, dto);

      expect(mockDirectiveService.update).toHaveBeenCalledWith(group_id, dto);
      expect(response).toEqual(result);
    });
  });


//   describe('POST /directive/switch-directive', () => {
//     it('should create a new switch directive', async () => {
//       const createDto = { name: 'New Directive' };
//       const result = { id: 1, ...createDto };
//       mockDirectiveService.create.mockResolvedValue(result);

//       expect(await controller.create(createDto)).toEqual(result);
//     });
//   });

//   describe('PUT /directive/switch-directive/:group_id', () => {
//     it('should update an existing switch directive', async () => {
//       const groupId = 1;
//       const updateDto = { name: 'Updated Directive' };
//       const result = { id: groupId, ...updateDto };
//       mockDirectiveService.update.mockResolvedValue(result);

//       expect(await controller.update(groupId, updateDto)).toEqual(result);
//     });
//   });

  describe('DELETE /directive/:id', () => {
    it('should delete a switch directive', async () => {
      const id = 1;
      mockDirectiveService.delete.mockResolvedValue(undefined);

      await expect(controller.remove(id)).resolves.toBeUndefined();
    });
  });

  describe('GET /directive/search/managers', () => {
    it('should return managers based on searchValue', async () => {
      const searchValue = 'test';
      const result = [{ id: 1, name: 'Manager 1' }];
      mockDirectiveService.typeaheadManagers.mockResolvedValue(result);

      expect(await controller.typeaheadManagers(searchValue)).toEqual(result);
    });

    it('should return an error message when searchValue is not provided', async () => {
      const result = { message: 'Please provide a search value' };
      expect(await controller.typeaheadManagers('')).toEqual(result);
    });
  });

  describe('GET /directive/manager/technicians', () => {
    it('should return technicians based on loginId and condition', async () => {
      const loginId = 'user1';
      const condition = 'true';
      const result = [{ id: 1, name: 'Technician 1' }];
      mockDirectiveService.getTechnicians.mockResolvedValue(result);

      expect(await controller.getTechnicians(loginId, condition)).toEqual(result);
    });
  });

  describe('GET /directive/element/division', () => {
    it('should return distinct element divisions', async () => {
      const result = ['Division 1', 'Division 2'];
      mockDirectiveService.getDistinctElementDivision.mockResolvedValue(result);

      expect(await controller.getElementDivision()).toEqual(result);
    });

    it('should throw an error when retrieval fails', async () => {
      mockDirectiveService.getDistinctElementDivision.mockRejectedValue(new Error('Failed to retrieve'));

      await expect(controller.getElementDivision()).rejects.toBeInstanceOf(InternalServerErrorException);
    });
  });

  describe('GET /directive/element/vendor', () => {
    it('should return distinct element vendors', async () => {
      const result = ['Vendor 1', 'Vendor 2'];
      mockDirectiveService.getDistinctElementVendor.mockResolvedValue(result);

      expect(await controller.getElementVendor()).toEqual(result);
    });

    it('should throw an error when retrieval fails', async () => {
      mockDirectiveService.getDistinctElementVendor.mockRejectedValue(new Error('Failed to retrieve'));

      await expect(controller.getElementVendor()).rejects.toBeInstanceOf(InternalServerErrorException);
    });
  });

  describe('GET /directive/elementDept/elementSubDept', () => {
    it('should return element details based on division and vendor', async () => {
      const elementDivision = 'division1';
      const vendor = 'vendor1';
      const result = [{ id: 1, name: 'Element 1' }];
      mockDirectiveService.getElementDetails.mockResolvedValue(result);

      expect(await controller.getElementDetails(elementDivision, vendor)).toEqual(result);
    });

    it('should throw an error when elementDivision or vendor is missing', async () => {
      await expect(controller.getElementDetails('', 'vendor1')).rejects.toBeInstanceOf(Error);
    });
  });

  describe('DataSource Integration', () => {
    it('should initialize the DataSource on application startup', async () => {
      await expect(dataSource.initialize).not.toThrow();
      expect(mockDataSource.initialize).toHaveBeenCalled();
    });

    it('should close the DataSource connection on teardown', async () => {
      await dataSource.destroy();
      expect(mockDataSource.destroy).toHaveBeenCalled();
    });

    it('should retrieve a repository for a given entity', () => {
      const repository = dataSource.getRepository('TestEntity');
      expect(repository).toBeDefined();
      expect(mockDataSource.getRepository).toHaveBeenCalledWith('TestEntity');
    });
  });
});