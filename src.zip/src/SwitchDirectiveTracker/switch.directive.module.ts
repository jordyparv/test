import {forwardRef, Module } from "@nestjs/common";
import { SwitchDirectiveService } from "./switch.directive.service";
import { SwitchDirectiveController } from "./switch.directive.controller";
import { oracleDbModule } from "src/common/database/oracle.module";

import {TypeOrmModule} from "@nestjs/typeorm";
import { DirectiveUserGroupMappingEntity } from "./entities/switch.directive.entity.DirectiveUserGroupMappingEntity";
import { DirectiveGroupEntity } from "./entities/switch.directive.entity.DirectiveGroupEntity";
import { SwitchElementEntity } from "./entities/switch.directive.entity.SwitchElementEntity";
import { DirectiveElementGroupMappingEntity } from "./entities/switch.directive.entity.DirectiveElementGroupMappingEntity";
import { SecContactEntity } from "./entities/switch.directive.entity.SecContactEntity";
import { SecUsersEntity } from "./entities/switch.directive.entity.SecUsersEntity";
import { SecRolesEntity } from "./entities/switch.directive.entity.SecRolesEntity";


@Module({
  imports:[oracleDbModule,
    TypeOrmModule.forFeature(
    [DirectiveUserGroupMappingEntity,
    DirectiveGroupEntity,
    SwitchElementEntity,
    DirectiveElementGroupMappingEntity,
    SecContactEntity,
    SecUsersEntity,
    SecRolesEntity
  ])],
  controllers:[SwitchDirectiveController],
  providers:[SwitchDirectiveService]
})
export class SwitchDirectiveModule{
  constructor(){}
}