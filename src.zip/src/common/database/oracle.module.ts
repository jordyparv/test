import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DirectiveElementGroupMappingEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.DirectiveElementGroupMappingEntity';
import { DirectiveGroupEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.DirectiveGroupEntity';
import { DirectiveUserGroupMappingEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.DirectiveUserGroupMappingEntity';
import { SecContactEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.SecContactEntity';
import { SecRolesEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.SecRolesEntity';
import { SecUsersEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.SecUsersEntity';
import { SwitchElementEntity } from 'src/SwitchDirectiveTracker/entities/switch.directive.entity.SwitchElementEntity';

let config = require("config");
let fs = require("fs");
let dbConfig = JSON?.parse(
  fs?.readFileSync(config?.iopdbConfig?.filePath, "utf8")
).db[0];

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'oracle',  // Specify that you are using Oracle
      host: dbConfig.host,  // e.g., 'localhost' or Oracle Cloud host
      port: dbConfig.port,  // Default Oracle port (this might vary)
      username: dbConfig.user,  // Oracle DB username
      password: dbConfig.password,  // Oracle DB password
      sid: dbConfig.dbName,  // Oracle SID or service name
      connectString: dbConfig.rac_string, // Optional (used if you have a TNS or full connection string)
      synchronize: false, // Set to true if you want TypeORM to automatically create DB schema on startup
      logging: true, // Optional - helps to log queries
      entities:[
        DirectiveUserGroupMappingEntity,
        DirectiveGroupEntity,
        SecContactEntity,
        SwitchElementEntity,
        DirectiveElementGroupMappingEntity,
        SecUsersEntity,
        SecRolesEntity
      ], // List of entities to be used in TypeORM
    }),
  ],
})



export class oracleDbModule {}