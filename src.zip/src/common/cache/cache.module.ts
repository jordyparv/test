import { DynamicModule, Global, Module } from '@nestjs/common';
import { cacheHelper } from './cache.helper';


@Global()
@Module({
  providers: [cacheHelper],
  exports: [cacheHelper],
})
export class cacheModule {}
