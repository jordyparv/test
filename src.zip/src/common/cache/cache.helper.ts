import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { RestClient } from '../util/restClient/restClient.service';
import { Buffer } from 'buffer';
import { head } from 'lodash';
const config = require('config');
// const restCLIENT = require('../util/restClient/restClient.util');
const _ = require('lodash');

@Injectable()
export class cacheHelper {
  entity: any;
  private readonly logger = new Logger(cacheHelper.name);
  constructor(private restClient: RestClient) {}

  async cacheIt(postdata: any, url, additionalProps?: any) {
    try {
      console.log('URL ', url);
      let cacheUrl = url;
      let headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      };
      this.logger.log('info',`cacheUrl : ${cacheUrl}`);

      let response = await this?.restClient?.upsert(postdata, cacheUrl, headers);
      console.log('response ',response)
      return response;
    } catch (err) {
      this.logger.error('error in cacheIt() ', err?.message);
      // console.log('err', err);
    }
    return 1;
  }

  async cacheUpdate(postdata: any, url, additionalProps?: any) {
    // console.log('postdata ', JSON.stringify(postdata));
    try {
      let cacheUrl = url;
      let args = {
        data: postdata,
      };
      let headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      };
      this.logger.log('info',`cacheUrl : ${cacheUrl}`);
      console.log("cacheee", cacheUrl);
      
      let response = await this?.restClient?.upsert(args, cacheUrl, headers);
      if(response?.message?.includes('413')){
        console.log('Request Entity too large =========>',response?.message)
      }else{
        console.log('upserted =========>',response?.message)
      }
      return response;
      
    } catch (err) {
      this.logger.error('error in cacheUpdate() ', err);
      // console.log('err', err);
    }
    return 1;
  }
  
  async getFromCache(args, callback) {
    try {
      if (!config?.cache?.enabled) {
        return null;
      }

      // let cacheUrl = "http://txsliopsa5v.nss.vzwnet.com:8080/cache/";
      let cacheUrl = config?.cache?.url;
      let headers = args?.headers;
      let parameters = args?.parameters;
      this.logger.log('info',`cacheUrl : ${cacheUrl}`);
      // console.log(`cacheUrl : ${cacheUrl}`)
      let data = await this?.restClient?.get(cacheUrl, headers, '', '', parameters).toPromise();
      // console.log("cache data ",data.data.records)
      return data && callback(data);
    } catch (error) {
      // console.log("error ",error)
      
      callback(null)
      this.logger.error('error in getFromCache () ', error?.message);
    }
  }
}
