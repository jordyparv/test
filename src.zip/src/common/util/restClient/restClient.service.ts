import { Body, Injectable } from '@nestjs/common';
import { Observable } from 'rxjs';
import axios, { AxiosRequestConfig } from 'axios';
import { HttpService} from '@nestjs/axios';

let config = require("config")
@Injectable()
export class RestClient {
  constructor(private httpService: HttpService) {}
  get(
    baseURL: any,
    headers?: any,
    url?: any,
    requestConfig?: any,
    parameters?: any
  ): Observable<any> {
    try {
      console.log("baseURL:", baseURL, headers);
      const axiosconfig: AxiosRequestConfig = {
        baseURL: baseURL,
        headers: headers,
        timeout: requestConfig,
        params: parameters,
      };
      // console.log("return")
      return this?.httpService?.get(url, axiosconfig);
    } catch (error) {
      console.log("async get err-->", error);
      return error;
    }
  }

  get1(
    baseURL: any,
    headers?: any,
    url?: any,
    requestConfig?: any,
    parameters?: any
  ): Observable<any> {
    try {
      console.log("baseURL:", baseURL);
      const axiosconfig: AxiosRequestConfig = {
        baseURL: baseURL,
        headers: headers,
        params: parameters,
      };
      // console.log("return")
      return this?.httpService?.get(url, axiosconfig);
    } catch (error) {
      console.log("async get err-->", error);
      return error;
    }
  }

  async post(baseURL: any, headers, data, url?: any): Promise<Observable<any>> {
    try {
      console.log("cache url ", baseURL);
      const axiosconfig: AxiosRequestConfig = {
        baseURL: baseURL,
        headers: headers,
        data: data,
      };

      let respo = await this?.httpService?.post(url, axiosconfig);
      console.log("respo ", respo);
      return respo;
    } catch (error) {
      console.log("post ", error);
      return error;
    }
  }

  async update(@Body() data: any, url, headers) {
    console.log("url => ", url, "data =>", data, "headers", headers);
    try {
      const response = await axios.post(url, data, { headers });
      return response?.data;
    } catch (error) {
      return error;
    }
  }

  async upsert(@Body() data: any, url, headers) {
    // console.log("insertion starts")
    // console.log("Data in restclient =======> ", data);

    try {
      const response = await axios.post(url, data, { headers });
      return response?.data;
    } catch (error) {
      return error;
    }
  }
  async post2(url,data){
    try {
      const {data:res} = await axios.post(url,data.data,data.headers)
      return res
    } catch (error) {
      console.error('api call failed',error.message)
      return error
    }
      }
}
