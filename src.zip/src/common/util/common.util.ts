import { v4 as uuidv4 } from 'uuid';
let geolib = require('geolib');
const _ = require('lodash')

export class CommonUtil {

    static async calculateDistance(source: any, destination: any, unit?: string) {
        try {
            unit = (unit) ? unit?.toUpperCase() : "MILES";
            let distance = geolib?.getDistance(source, destination)?.toFixed(2);
            let distanceText = "";

            switch (unit) {
                case "MILES":
                    distanceText = (distance * 0.000621371).toFixed(2) + " Miles ";
                    break;

                case "KMS":
                    distanceText = (distance * 0.001).toFixed(2) + "Kms";
                    break;

                case "FEET":
                    distanceText = (distance * 3.28084).toFixed(2) + "Feet";
                    break;

                default:
                    distanceText = (distance * 0.000621371).toFixed(2) + " Miles ";
            }
            let o = { distanceText: distanceText, distance: distance };
            return o;
        } catch (error) {
            console.log("error in calculate distance ", error);
        }
    }

    // checking if data is empty or not
    static isEmpty(val: any): boolean {
        const notValidValues = [null, "", undefined, "null", true, false];
    // Check for other invalid values
        return (
            notValidValues.includes(val) || (Array.isArray(val) && val.length === 0) || // Check for empty arrays
            (typeof val === 'object' && Object.keys(val).length === 0) // Check for empty objects
           
        );
    }

    // Generate meta_universalid without dashes and in uppercase
    static generateMetaUniversalId(): string {
        return uuidv4().replace(/-/g, '').toUpperCase();
    }
    static sanitizeString = (str: string) => {
            
        str = str.replace(/[^a-zA-Z0-9 \.,_\-()&\/:;#@!+*?~%^=|'"`<>]/gim, "");
        return str.trim();
    };
    
    static isEmptyString(str:string){
        if(typeof str !=='string')
            return true
        return !str
    }
    static suffixWildChar(val: string) {
        return `${val}%`;
      }
      static encloseWildChar(val: string) {
        return `%${val}%`;
      }

    //validate start and end date
    static isValidDateFormat(startDate: string, endDate: string): boolean {
        return startDate && endDate && new Date(startDate) < new Date(endDate);
    }
    static formatDate(dateStr: string = "") {
        const date = dateStr ? new Date(dateStr) : new Date();
        const year = date.getFullYear().toString().slice(-2); 
        const month = date.toLocaleString('en-US', { month: 'short' }).toUpperCase();
        const day = date.getDate().toString().padStart(2, '0');
        let hours = date.getUTCHours();
        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
        const seconds = date.getUTCSeconds().toString().padStart(2, '0');
        const milliseconds = date.getUTCMilliseconds().toString().padStart(7, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
 
        hours = hours % 12;
        hours = hours ? hours : 12;
 
        return `${day}-${month}-${year} ${hours}.${minutes}.${seconds}.${milliseconds} ${ampm}`; 
    } 
 
    static toLowerCaseKeys(input: any): any {
        if (Array.isArray(input)) {
          return input
            .map(item => this.toLowerCaseKeys(item))
            .filter(item => item !== null && item !== undefined && !(typeof item === 'object' && Object.keys(item).length === 0));
        } else if (input !== null && typeof input === 'object') {
          // If it's a Date object, return it as is
          if (input instanceof Date) {
            return input;
          }
      
          const result = _.mapValues(
            _.mapKeys(input, (value, key) => key.toLowerCase()), 
            value => this.toLowerCaseKeys(value)
          );
          
          // Return undefined for empty objects
          return Object.keys(result).length > 0 ? result : undefined;
        }
      
        return input;
      }
    

    static compareElements(ele1: any, ele2: any) {
        if(Object.keys(ele1).length === Object.keys(ele2).length) {
            for(let key of Object.keys(ele1))  {
                if((ele2[key] && typeof ele2[key] === 'object') || key === "notificationOverrides") continue;
                if(ele1[key] !== ele2[key]) return false;
            }
            return true;
        }
        return false;
    }

    static compareSubElements(subEle1: any, subEle2: any) {
        if(subEle1?.length !== subEle2?.length) {
            return false;
        }
        for(let i = 0; i < subEle1?.length; i++) {
            if(subEle1[i]?.["vsm_name"] !== subEle2[i]?.["vsm_name"] || (subEle1[i]?.["role"] !== subEle2[i]?.["role"])) return false;
        }
        return true;
    }

    static formatDateString(date: string) {
        const [month, day, year] = date?.split("-");
        return `${year}-${month}-${day}`
    }
      
}
