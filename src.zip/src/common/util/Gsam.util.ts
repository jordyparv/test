const FS = require('fs');
const config = require('config')

export class GsamUtil{
    constructor(){}

    static async restrictData(data, field){
        try {
            const gsamSensitiveDictionary = await JSON?.parse(FS?.readFileSync(config?.gsamDetailsFilePath, 'utf8'));
        for (let i = data?.length - 1; i >= 0; i--) {
            innerBlock: {
                for (let j = 0; j < field?.length; j++) {
                    if (gsamSensitiveDictionary?.some(substring => data[i][field[j]]?.toUpperCase()?.includes(substring))) {
                        data?.splice(i, 1);
                        break innerBlock;
                    }
                }
            }
        }
        } catch (error) {
            console.log("error in GsamUtil ",error)
        }
        
    }

}