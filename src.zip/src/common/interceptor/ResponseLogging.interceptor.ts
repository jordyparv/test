import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class ResponseLoggingInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    // if (context) {
    // const statusCode = context.switchToHttp().getResponse().statusCode;
    const body = context?.switchToHttp()?.getRequest()?.body;
    return next?.handle()?.pipe(
      tap((responseData: any) => {
        console.log({ data: 'test' });
      }),
    );
    // }
  }
}
