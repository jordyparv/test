import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
} from '@nestjs/common';
import { HttpException } from '@nestjs/common/exceptions';
import { Request, Response } from 'express';


@Catch(HttpException)
export class HttpRequestExceptionFilter implements ExceptionFilter {
  catch(exception: HttpException, host: ArgumentsHost) {
    const ctx = host?.switchToHttp();
    const response = ctx?.getResponse<Response>();
    const request = ctx?.getRequest<Request>();
    const status = exception?.getStatus();
    const errors: any = exception?.getResponse()
    console.log({errors})

    const logError = {
      status: status,
      title: errors?.title,
      detail: errors?.detail,
      message:errors?.message,
      ...errors
     };
    let final = {errors:[logError]};
    response?.status(status)?.json(final);
  }
}